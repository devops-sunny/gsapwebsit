# Security Policy

Please report (suspected) security vulnerabilities to
**[info@greensock.com](mailto:info@greensock.com)**. You will receive a response from
us within 72 hours. If the issue is confirmed, we will release a patch as soon
as possible depending on complexity.